<?php
require_once 'config/database.php';

try {
    // Check if employees table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'employees'");
    $tableExists = $stmt->rowCount() > 0;
    
    if (!$tableExists) {
        // Create employees table
        $createTable = "
            CREATE TABLE employees (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                role ENUM('admin', 'manager', 'staff', 'cashier') NOT NULL,
                phone VARCHAR(20),
                status ENUM('active', 'inactive') DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            );
        ";
        
        $pdo->exec($createTable);
        echo json_encode([
            'success' => true,
            'message' => 'Employees table created successfully'
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'message' => 'Employees table already exists'
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
