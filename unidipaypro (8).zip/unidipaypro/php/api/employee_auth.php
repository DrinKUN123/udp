<?php
/**
 * Employee Authentication API
 * Handles employee login, logout, and session management
 */

// Start session first before any headers
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'login':
            if ($method !== 'POST') {
                sendResponse(['error' => 'Method not allowed'], 405);
            }
            handleEmployeeLogin();
            break;
            
        case 'logout':
            handleEmployeeLogout();
            break;
            
        case 'check':
            checkEmployeeSession();
            break;
            
        default:
            sendResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    error_log("Employee Auth Error: " . $e->getMessage());
    sendResponse(['error' => $e->getMessage()], 500);
}

/**
 * Handle employee login
 */
function handleEmployeeLogin() {
    global $pdo;
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['email']) || empty($data['password'])) {
        sendResponse(['error' => 'Email and password are required'], 400);
    }
    
    $email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
    $password = $data['password'];
    
    try {
        $stmt = $pdo->prepare("SELECT id, name, email, role, status, password FROM employees WHERE email = ?");
        $stmt->execute([$email]);
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$employee) {
            sendResponse(['error' => 'Invalid email or password'], 401);
        }
        
        // Check if employee is active
        if ($employee['status'] !== 'active') {
            sendResponse(['error' => 'Your account is inactive. Contact administration.'], 403);
        }
        
        // Verify password
        if (!password_verify($password, $employee['password'])) {
            sendResponse(['error' => 'Invalid email or password'], 401);
        }
        
        // Set session
        $_SESSION['employee_id'] = $employee['id'];
        $_SESSION['employee_name'] = $employee['name'];
        $_SESSION['employee_email'] = $employee['email'];
        $_SESSION['employee_role'] = $employee['role'];
        
        sendResponse([
            'success' => true,
            'employee' => [
                'id' => $employee['id'],
                'name' => $employee['name'],
                'email' => $employee['email'],
                'role' => $employee['role']
            ]
        ]);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        sendResponse(['error' => 'Database error occurred'], 500);
    }
}

/**
 * Handle employee logout
 */
function handleEmployeeLogout() {
    session_unset();
    session_destroy();
    sendResponse(['success' => true]);
}

/**
 * Check if employee session is active
 */
function checkEmployeeSession() {
    if (isset($_SESSION['employee_id']) && !empty($_SESSION['employee_id'])) {
        sendResponse([
            'loggedIn' => true,
            'employee' => [
                'id' => $_SESSION['employee_id'],
                'name' => $_SESSION['employee_name'],
                'email' => $_SESSION['employee_email'],
                'role' => $_SESSION['employee_role']
            ]
        ]);
    } else {
        sendResponse(['loggedIn' => false]);
    }
}
?>
