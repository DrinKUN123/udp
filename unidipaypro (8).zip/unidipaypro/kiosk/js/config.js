// API Configuration
const API_BASE_URL = 'api';

// API Endpoints
const API_ENDPOINTS = {
    getMenuItems: `${API_BASE_URL}/get_menu_items.php`,
    createOrder: `${API_BASE_URL}/create_order.php`,
    verifyCard: `${API_BASE_URL}/verify_card.php`
};
