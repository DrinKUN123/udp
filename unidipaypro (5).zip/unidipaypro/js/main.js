/**
 * UniDiPay - Common JavaScript Functions
 * Shared utilities for all pages
 */

// API Base URL
const API_BASE = 'php/api/';

/**
 * Check if user is authenticated
 */
async function checkAuth() {
    try {
        const response = await fetch(`${API_BASE}auth.php?action=check`);
        const data = await response.json();
        return data.loggedIn;
    } catch (error) {
        console.error('Auth check error:', error);
        return false;
    }
}

/**
 * Get logged in admin info
 */
function getAdmin() {
    const admin = localStorage.getItem('admin');
    return admin ? JSON.parse(admin) : null;
}

/**
 * Logout user
 */
async function logout() {
    try {
        await fetch(`${API_BASE}auth.php?action=logout`);
        localStorage.removeItem('admin');
        window.location.href = 'index.html';
    } catch (error) {
        console.error('Logout error:', error);
    }
}

/**
 * Make authenticated API request
 */
async function apiRequest(endpoint, options = {}) {
    try {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Request failed');
        }
        
        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

/**
 * Show success message
 */
function showSuccess(message) {
    showToast(message, 'success');
}

/**
 * Show error message
 */
function showError(message) {
    showToast(message, 'error');
}

/**
 * Simple toast notification
 */
function showToast(message, type = 'info') {
    // Remove existing toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 16px 24px;
        border-radius: 8px;
        background: ${type === 'success' ? '#10B981' : type === 'error' ? '#EF4444' : '#2563EB'};
        color: white;
        font-size: 14px;
        font-weight: 500;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        z-index: 9999;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

/**
 * Format currency
 */
function formatCurrency(amount) {
    return '₱' + parseFloat(amount).toFixed(2);
}

/**
 * Format date/time
 */
function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('en-PH', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

/**
 * Format date only
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-PH', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

/**
 * Confirm action
 */
function confirmAction(message) {
    return confirm(message);
}

/**
 * Show loading state
 */
function showLoading(container) {
    container.innerHTML = `
        <div class="loading">
            <div class="loading-spinner"></div>
            <p>Loading...</p>
        </div>
    `;
}

/**
 * Show empty state
 */
function showEmpty(container, message = 'No data available') {
    container.innerHTML = `
        <div class="empty-state">
            <div class="empty-icon">📭</div>
            <p>${message}</p>
        </div>
    `;
}

/**
 * Protect page - redirect if not logged in
 */
async function protectPage() {
    const isAuthenticated = await checkAuth();
    if (!isAuthenticated) {
        window.location.href = 'index.html';
    }
}

/**
 * Initialize common elements on dashboard pages
 */
function initDashboard() {
    // Set admin name
    const admin = getAdmin();
    const adminNameEl = document.getElementById('adminName');
    if (adminNameEl && admin) {
        adminNameEl.textContent = admin.name;
    }
    
    // Setup logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    }
    
    // Highlight current nav item
    highlightCurrentNav();
}

/**
 * Highlight current navigation item
 */
function highlightCurrentNav() {
    const currentPage = window.location.pathname.split('/').pop();
    const navItems = document.querySelectorAll('.nav-item');
    
    navItems.forEach(item => {
        const href = item.getAttribute('href');
        if (href === currentPage) {
            item.classList.add('active');
        }
    });
}

/**
 * Export table to CSV
 */
function exportToCSV(filename, data, headers) {
    let csv = headers.join(',') + '\n';
    
    data.forEach(row => {
        csv += row.map(cell => {
            // Escape commas and quotes
            if (typeof cell === 'string' && (cell.includes(',') || cell.includes('"'))) {
                return '"' + cell.replace(/"/g, '""') + '"';
            }
            return cell;
        }).join(',') + '\n';
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

/**
 * Debounce function for search
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Export functions for use in other scripts
window.UniDiPay = {
    checkAuth,
    getAdmin,
    logout,
    apiRequest,
    showSuccess,
    showError,
    showToast,
    formatCurrency,
    formatDateTime,
    formatDate,
    confirmAction,
    showLoading,
    showEmpty,
    protectPage,
    initDashboard,
    exportToCSV,
    debounce
};
// MENU PAGE MODULE
const Menu = {
    loadMenuItems: async (category = "all") => {
        const grid = document.getElementById("menuGrid");
        UniDiPay.showLoading(grid);

        let url = category === "all"
            ? "menu.php?action=all"
            : `menu.php?action=category&category=${category}`;

        const res = await UniDiPay.apiRequest(url);
        const items = res.menu_items;

        if (!items.length) return UniDiPay.showEmpty(grid);

        grid.innerHTML = items.map(item => `
            <div class="menu-card">
                <img src="${item.image_url || 'https://via.placeholder.com/200'}">

                <div class="title">${item.name}</div>
                <div class="price">₱${item.price}</div>

                <div class="availability">
                    <label class="switch">
                        <input type="checkbox" ${item.available == 1 ? "checked" : ""} 
                            onchange="Menu.toggleAvailability(${item.id}, this.checked)">
                        <span class="slider"></span>
                    </label>
                    <span class="status-text ${item.available ? "available" : "unavailable"}">
                        ${item.available ? "Available" : "Unavailable"}
                    </span>
                </div>

                <div class="actions">
                    <button class="btn-edit" onclick="Menu.editItem(${item.id})">Edit</button>
                    <button class="btn-delete" onclick="Menu.deleteItem(${item.id})">Delete</button>
                </div>
            </div>
        `).join('');
    },

    openAddModal: () => {
        document.getElementById("modalTitle").textContent = "Add Menu Item";
        document.getElementById("menuForm").reset();
        document.getElementById("menuModal").classList.add("show");
    },

    editItem: async id => {
        const res = await UniDiPay.apiRequest(`menu.php?action=single&id=${id}`);
        const item = res.menu_item;

        document.getElementById("modalTitle").textContent = "Edit Menu Item";
        document.getElementById("menuId").value = item.id;
        document.getElementById("menuName").value = item.name;
        document.getElementById("menuCategory").value = item.category;
        document.getElementById("menuPrice").value = item.price;
        document.getElementById("menuDescription").value = item.description;
        document.getElementById("menuImage").value = item.image_url;

        document.getElementById("menuModal").classList.add("show");
    },

    deleteItem: async id => {
        if (!confirm("Delete menu item?")) return;

        await UniDiPay.apiRequest(`menu.php?id=${id}`, { method: "DELETE" });
        UniDiPay.showSuccess("Menu item deleted");
        Menu.loadMenuItems("all");
    },

    // ✅ YOUR NEW FUNCTION (inserted here)
    toggleAvailability: async (id, status) => {
        try {
            await UniDiPay.apiRequest("menu.php", {
                method: "PUT",
                body: JSON.stringify({
                    id: id,
                    available: status ? 1 : 0
                })
            });

            UniDiPay.showSuccess(status ? "Item set to Available" : "Item set to Unavailable");

            // Refresh current filter
            const current = document.querySelector(".filter-btn.active").dataset.category;
            Menu.loadMenuItems(current);

        } catch (err) {
            UniDiPay.showError("Failed to update availability");
            console.error(err);
        }
    }
};

window.Menu = Menu;


/**
 * MENU MANAGEMENT FUNCTIONS
 */

window.Menu = {
    async loadMenuItems(category = 'all') {
        const container = document.getElementById('menuList');
        UniDiPay.showLoading(container);

        try {
            const res = await UniDiPay.apiRequest(`menu.php?action=${category}`);
            
            const items = res.menu_items;
            if (!items || items.length === 0) {
                UniDiPay.showEmpty(container, 'No menu items found');
                return;
            }

            container.innerHTML = items.map(item => `
                <div class="menu-card">
                    <img src="${item.image_url || 'https://via.placeholder.com/150'}" class="menu-img">
                    <div class="menu-info">
                        <h3>${item.name}</h3>
                        <p>${item.description}</p>
                        <div class="menu-bottom">
                            <span class="price">₱${parseFloat(item.price).toFixed(2)}</span>
                            <span class="category">${item.category}</span>
                        </div>
                    </div>
                </div>
            `).join('');
        } catch (error) {
            UniDiPay.showError("Failed to load menu");
        }
    }
};
