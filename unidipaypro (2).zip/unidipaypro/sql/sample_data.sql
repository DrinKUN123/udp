-- ============================================
-- UniDiPay Sample Data
-- Demo students, menu items, and initial data
-- ============================================

-- Insert demo students
INSERT INTO students (name, student_id, program, year_level, nfc_card_id) VALUES
('Juan Dela Cruz', '2021-00001', 'BSCS', '3rd Year', 'NFC001'),
('Maria Santos', '2021-00002', 'BSIT', '2nd Year', 'NFC002'),
('Pedro Garcia', '2022-00003', 'BSIS', '1st Year', 'NFC003');

-- Insert NFC cards with initial balance
INSERT INTO nfc_cards (id, student_id, balance) VALUES
('NFC001', 1, 500.00),
('NFC002', 2, 500.00),
('NFC003', 3, 500.00);

-- Insert demo menu items
INSERT INTO menu_items (name, category, price, description, available) VALUES
-- Meals
('Chicken Adobo with Rice', 'Meals', 65.00, 'Filipino classic chicken adobo served with steamed rice', TRUE),
('Pork Sinigang', 'Meals', 70.00, 'Sour pork soup with vegetables', TRUE),
('Beef Tapa', 'Meals', 75.00, 'Marinated beef with garlic rice and egg', TRUE),
('Pancit Canton', 'Meals', 50.00, 'Stir-fried noodles with vegetables', TRUE),

-- Drinks
('Iced Coffee', 'Drinks', 35.00, 'Cold brew coffee', TRUE),
('Fresh Mango Juice', 'Drinks', 40.00, 'Pure mango juice', TRUE),
('Bottled Water', 'Drinks', 15.00, 'Mineral water 500ml', TRUE),
('Calamansi Juice', 'Drinks', 25.00, 'Fresh calamansi juice', TRUE),

-- Snacks
('Banana Cue', 'Snacks', 20.00, 'Caramelized banana on stick', TRUE),
('Turon', 'Snacks', 25.00, 'Fried banana spring roll with jackfruit', TRUE),
('Fish Ball', 'Snacks', 15.00, '10 pieces with sauce', TRUE),
('Kikiam', 'Snacks', 20.00, 'Filipino-style pork sausage', TRUE),

-- Desserts
('Leche Flan', 'Desserts', 30.00, 'Caramel custard dessert', TRUE),
('Halo-Halo', 'Desserts', 45.00, 'Mixed dessert with shaved ice', TRUE),
('Buko Pandan', 'Desserts', 35.00, 'Young coconut and pandan jelly dessert', TRUE);

-- Insert initial reload transactions for demo cards
INSERT INTO reloads (card_id, amount, admin_id, balance_before, balance_after) VALUES
('NFC001', 500.00, 1, 0.00, 500.00),
('NFC002', 500.00, 1, 0.00, 500.00),
('NFC003', 500.00, 1, 0.00, 500.00);

-- ============================================
-- Sample Orders (Optional - for testing)
-- ============================================

-- Sample Order 1
INSERT INTO orders (student_id, nfc_card_id, total, status, created_at) VALUES
(1, 'NFC001', 100.00, 'completed', DATE_SUB(NOW(), INTERVAL 2 DAY));

INSERT INTO order_items (order_id, menu_item_id, name, price, quantity, subtotal) VALUES
(1, 1, 'Chicken Adobo with Rice', 65.00, 1, 65.00),
(1, 5, 'Iced Coffee', 35.00, 1, 35.00);

INSERT INTO transactions (card_id, type, amount, reason, order_id, balance_before, balance_after, created_at) VALUES
('NFC001', 'debit', 100.00, 'Order #1', 1, 500.00, 400.00, DATE_SUB(NOW(), INTERVAL 2 DAY));

UPDATE nfc_cards SET balance = 400.00 WHERE id = 'NFC001';

-- Sample Order 2
INSERT INTO orders (student_id, nfc_card_id, total, status, created_at) VALUES
(2, 'NFC002', 95.00, 'completed', DATE_SUB(NOW(), INTERVAL 1 DAY));

INSERT INTO order_items (order_id, menu_item_id, name, price, quantity, subtotal) VALUES
(2, 2, 'Pork Sinigang', 70.00, 1, 70.00),
(2, 9, 'Banana Cue', 20.00, 1, 20.00),
(2, 8, 'Calamansi Juice', 25.00, 1, 25.00);

-- Update balance
UPDATE nfc_cards SET balance = 405.00 WHERE id = 'NFC002';

INSERT INTO transactions (card_id, type, amount, reason, order_id, balance_before, balance_after, created_at) VALUES
('NFC002', 'debit', 95.00, 'Order #2', 2, 500.00, 405.00, DATE_SUB(NOW(), INTERVAL 1 DAY));

-- Sample Pending Order
INSERT INTO orders (student_id, nfc_card_id, total, status) VALUES
(3, 'NFC003', 80.00, 'pending');

INSERT INTO order_items (order_id, menu_item_id, name, price, quantity, subtotal) VALUES
(3, 3, 'Beef Tapa', 75.00, 1, 75.00),
(3, 7, 'Bottled Water', 15.00, 1, 15.00);

-- Update balance
UPDATE nfc_cards SET balance = 420.00 WHERE id = 'NFC003';

INSERT INTO transactions (card_id, type, amount, reason, order_id, balance_before, balance_after) VALUES
('NFC003', 'debit', 80.00, 'Order #3', 3, 500.00, 420.00);

-- ============================================
-- Additional Reload Example
-- ============================================
INSERT INTO reloads (card_id, amount, admin_id, balance_before, balance_after, created_at) VALUES
('NFC001', 200.00, 1, 400.00, 600.00, DATE_SUB(NOW(), INTERVAL 5 HOUR));

UPDATE nfc_cards SET balance = 600.00 WHERE id = 'NFC001';

-- ============================================
-- END OF SAMPLE DATA
-- ============================================
