# Employee System Integration Guide

## Overview
The UniDiPay system has a fully integrated employee management and authentication system that allows admins to create employee accounts, and employees to login to their dedicated station dashboards.

## System Architecture

### 1. **Employee Management (Admin Panel)**
**File:** `Emloyees role.html`
- Admins create, edit, and manage employee accounts
- Employees are stored in the `employees` database table with:
  - name, email, password (bcrypt hashed), role, phone, status
  - Roles: admin, manager, staff, cashier
  - Status: active, inactive

### 2. **Employee Authentication API**
**File:** `php/api/employee_auth.php`
- Handles employee login with email/password validation
- Creates secure sessions with employee data
- Validates employee status (must be 'active')
- Returns employee info including role for dashboard redirect

### 3. **Employee Station System**
**Folder:** `Emloyees stations/`
- `index.html` - Employee login portal
- `staff.html` - Staff dashboard (tasks & shifts)
- `manager.html` - Manager dashboard (team oversight)
- `cashier.html` - Cashier dashboard (transactions)

## Complete User Flow

### Step 1: Admin Creates Employee Account
1. Admin goes to `Emloyees role.html`
2. Clicks "✨ Create Employee" button
3. Fills in form:
   - Name: Employee's full name
   - Email: Their login email
   - Password: Set initial password
   - Role: Select (staff, manager, or cashier)
   - Phone: Optional
   - Status: Set to "active"
4. System stores employee in `employees` table with bcrypt-hashed password

### Step 2: Employee Logs In
1. Employee opens `Emloyees stations/index.html`
2. Enters email and password
3. System calls `php/api/employee_auth.php?action=login`
4. API validates:
   - Email exists in employees table
   - Password matches (bcrypt verify)
   - Account status is 'active'
5. Creates session and returns employee role

### Step 3: Employee Accesses Dashboard
1. Based on role, employee is redirected:
   - **staff** → `staff.html`
   - **manager** → `manager.html`
   - **cashier** → `cashier.html`
2. Employee info stored in localStorage for client-side use
3. Dashboard displays employee name, role, and role-specific features

### Step 4: Employee Logout
1. Employee clicks logout button
2. localStorage is cleared
3. Session is destroyed via `employee_auth.php?action=logout`
4. Redirected back to login page

## Database Schema

```sql
CREATE TABLE employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'manager', 'staff', 'cashier') DEFAULT 'staff',
    phone VARCHAR(20),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_role (role),
    INDEX idx_status (status)
);
```

## API Endpoints

### Employee Authentication
**Base URL:** `php/api/employee_auth.php`

#### Login
- **Endpoint:** `?action=login`
- **Method:** POST
- **Body:** `{ "email": "...", "password": "..." }`
- **Response:** `{ "success": true, "employee": { id, name, email, role } }`

#### Check Session
- **Endpoint:** `?action=check`
- **Method:** GET
- **Response:** `{ "loggedIn": true/false, "employee": {...} }`

#### Logout
- **Endpoint:** `?action=logout`
- **Method:** POST
- **Response:** `{ "success": true }`

### Employee Management (Admin)
**Base URL:** `php/api/emloyees role.php`

#### Create Employee
- **Endpoint:** `?action=create`
- **Method:** POST
- **Body:** `{ "name": "...", "email": "...", "password": "...", "role": "...", "status": "active", "phone": "..." }`

#### List Employees
- **Endpoint:** `?action=list`
- **Method:** GET
- **Response:** Array of employees

#### Get Single Employee
- **Endpoint:** `?action=get&id=<employee_id>`
- **Method:** GET

#### Update Employee
- **Endpoint:** `?action=update&id=<employee_id>`
- **Method:** POST

#### Delete Employee
- **Endpoint:** `?action=delete&id=<employee_id>`
- **Method:** DELETE

## Security Features

1. **Password Hashing:** bcrypt with PASSWORD_BCRYPT
2. **Session Management:** Secure PHP sessions
3. **Email Validation:** Filter SANITIZE_EMAIL
4. **Status Check:** Only active employees can login
5. **Database Indexes:** Optimized queries on email, role, status
6. **CORS Headers:** Configured in authentication API
7. **localStorage:** Client-side session persistence

## Dashboard Features by Role

### Staff Dashboard (`staff.html`)
- ✅ Daily tasks checklist
- ✅ Active orders tracking
- ✅ Shift information (start/end times)
- ✅ Real-time shift countdown
- ✅ Quick actions

### Manager Dashboard (`manager.html`)
- ✅ Team status table
- ✅ Performance metrics
- ✅ Orders overview
- ✅ Staff schedule management
- ✅ Quick action buttons

### Cashier Dashboard (`cashier.html`)
- ✅ Daily sales summary
- ✅ Transaction history
- ✅ Cash drawer tracking
- ✅ Payment methods breakdown
- ✅ Quick reconciliation

## Testing the Integration

### Test Employee Account
1. Go to `Emloyees role.html`
2. Create test account:
   - Name: Test Staff
   - Email: test@unidipay.com
   - Password: test123456
   - Role: staff
   - Status: active
3. Go to `Emloyees stations/index.html`
4. Login with:
   - Email: test@unidipay.com
   - Password: test123456
5. Should redirect to `staff.html` and display "Test Staff"

### Test Different Roles
- Create accounts with role: **manager** → logs into `manager.html`
- Create accounts with role: **cashier** → logs into `cashier.html`

### Test Inactive Account
1. Create employee with status: **inactive**
2. Try to login
3. Should show: "Your account is inactive. Contact administration."

### Test Invalid Credentials
1. Wrong email → "Invalid email or password"
2. Wrong password → "Invalid email or password"

## File Structure

```
unidipaypro/
├── Emloyees role.html                    # Admin: Manage employees
├── Emloyees stations/
│   ├── index.html                        # Employee login portal
│   ├── staff.html                        # Staff dashboard
│   ├── manager.html                      # Manager dashboard
│   ├── cashier.html                      # Cashier dashboard
│   └── Emloyees stations.css             # Shared CSS
├── php/
│   ├── api/
│   │   ├── employee_auth.php             # Authentication API
│   │   └── emloyees role.php             # Admin employee management API
│   └── config/
│       └── database.php                  # Database connection
└── css/
    └── style.css                         # Main stylesheet
```

## Environment Setup

1. **Database:** MySQL (included in XAMPP)
2. **PHP Version:** 5.6+ (XAMPP includes)
3. **Port:** Default XAMPP port (localhost:80 or localhost:8080)
4. **Database Name:** `unidipay_db`
5. **Database User:** `root` (no password)

## Troubleshooting

### Login Not Working
1. Check database connection: `php/config/database.php`
2. Verify employees table exists: `SELECT * FROM employees;`
3. Check browser console for fetch errors
4. Verify API path: should be `../php/api/employee_auth.php`

### Role-Based Redirect Not Working
1. Check if localStorage contains `employee` JSON
2. Verify role value matches file name (staff, manager, cashier)
3. Check browser console for redirect issues

### Password Reset
- Admins cannot reset passwords currently
- Workaround: Delete employee and recreate with new password

### Session Persistence
- Uses both PHP sessions and localStorage
- Clear both when testing logout functionality

## Future Enhancements

- [ ] Password reset functionality
- [ ] Two-factor authentication
- [ ] Role-based access control (RBAC)
- [ ] Activity logging
- [ ] Real-time data sync
- [ ] Notification system
- [ ] Mobile app compatibility
- [ ] API token authentication
