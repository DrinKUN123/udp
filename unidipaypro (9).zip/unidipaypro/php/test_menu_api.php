<?php
// Test menu API directly
error_reporting(E_ALL);
ini_set('display_errors', '0');  // Don't display errors as HTML
ini_set('log_errors', '1');

// Clean any previous output
while (ob_get_level()) {
    ob_end_clean();
}
ob_start();

require_once __DIR__ . '/api/menu.php';
?>
