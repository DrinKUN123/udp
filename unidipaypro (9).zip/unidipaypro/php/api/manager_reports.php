<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

session_start();

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$action = $_GET['action'] ?? '';
$manager_id = $_SESSION['employee_id'] ?? $_GET['manager_id'] ?? null;

// Parse JSON or form data
$input = [];
if ($_SERVER['CONTENT_TYPE'] === 'application/json' || strpos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
} else {
    $input = $_POST;
}

function sendJsonResponse($success, $message = '', $data = []) {
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

try {
    // Connect to database using PDO
    $pdo = new PDO(
        "mysql:host=localhost;dbname=unidipay_db;charset=utf8mb4",
        "root",
        "",
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

    switch ($action) {
        case 'daily_sales':
            // Get daily sales summary
            $query = "SELECT 
                        COUNT(*) as total_orders,
                        SUM(total) as total_sales,
                        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_orders,
                        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_orders,
                        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_orders,
                        AVG(total) as avg_order_value
                     FROM orders 
                     WHERE DATE(created_at) = CURDATE()";
            
            $stmt = $pdo->query($query);
            $report = $stmt->fetch(PDO::FETCH_ASSOC);
            
            sendJsonResponse(true, 'Daily sales report retrieved', [
                'total_orders' => (int)($report['total_orders'] ?? 0),
                'total_sales' => number_format((float)($report['total_sales'] ?? 0), 2),
                'completed_orders' => (int)($report['completed_orders'] ?? 0),
                'active_orders' => (int)($report['active_orders'] ?? 0),
                'pending_orders' => (int)($report['pending_orders'] ?? 0),
                'avg_order_value' => number_format((float)($report['avg_order_value'] ?? 0), 2),
                'report_date' => date('Y-m-d'),
                'report_time' => date('H:i:s')
            ]);
            break;

        case 'staff_performance':
            // Get staff performance metrics
            $query = "SELECT 
                        e.id,
                        e.name,
                        e.role,
                        COUNT(o.id) as orders_prepared,
                        COUNT(CASE WHEN o.status = 'completed' THEN 1 END) as orders_completed,
                        AVG(TIMESTAMPDIFF(MINUTE, o.created_at, o.completed_at)) as avg_completion_time
                     FROM employees e
                     LEFT JOIN orders o ON e.id = o.student_id AND DATE(o.created_at) = CURDATE()
                     WHERE e.status = 'active' AND e.role IN ('staff', 'cashier')
                     GROUP BY e.id, e.name, e.role
                     ORDER BY orders_completed DESC";
            
            $stmt = $pdo->query($query);
            $staff = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            sendJsonResponse(true, 'Staff performance report retrieved', ['staff' => $staff]);
            break;

        case 'order_completion':
            // Get order completion rate
            $query = "SELECT 
                        COUNT(*) as total_orders,
                        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_orders,
                        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_orders,
                        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_orders
                     FROM orders
                     WHERE DATE(created_at) = CURDATE()";
            
            $stmt = $pdo->query($query);
            $report = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $rate = (int)($report['total_orders'] ?? 0) > 0 ? ((int)($report['completed_orders'] ?? 0) * 100 / (int)($report['total_orders'] ?? 1)) : 0;
            
            sendJsonResponse(true, 'Order completion report retrieved', [
                'total_orders' => (int)($report['total_orders'] ?? 0),
                'completed_orders' => (int)($report['completed_orders'] ?? 0),
                'completion_rate' => number_format($rate, 2),
                'active_orders' => (int)($report['active_orders'] ?? 0),
                'pending_orders' => (int)($report['pending_orders'] ?? 0)
            ]);
            break;

        case 'hourly_analysis':
            // Get hourly sales and orders analysis
            $query = "SELECT 
                        HOUR(created_at) as hour,
                        COUNT(*) as orders_count,
                        SUM(total) as sales,
                        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed
                     FROM orders
                     WHERE DATE(created_at) = CURDATE()
                     GROUP BY HOUR(created_at)
                     ORDER BY hour ASC";
            
            $stmt = $pdo->query($query);
            $hourly = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            sendJsonResponse(true, 'Hourly analysis retrieved', ['hourly_data' => $hourly]);
            break;

        case 'send_message':
            // Send message to team
            $to_all = $input['to_all'] ?? false;
            $message_text = $input['message'] ?? '';
            $recipient_ids = $input['recipient_ids'] ?? [];
            
            if (!$message_text) {
                sendJsonResponse(false, 'Message cannot be empty');
            }
            
            // Create messages table if it doesn't exist
            $createTable = "CREATE TABLE IF NOT EXISTS messages (
                id INT PRIMARY KEY AUTO_INCREMENT,
                from_id INT,
                to_id INT,
                message TEXT,
                is_broadcast BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                read_at TIMESTAMP NULL,
                FOREIGN KEY (from_id) REFERENCES employees(id)
            )";
            
            try {
                $pdo->query($createTable);
            } catch (Exception $e) {
                // Table might already exist, continue
            }
            
            if ($to_all) {
                // Send to all staff
                $query = "INSERT INTO messages (from_id, message, is_broadcast, created_at)
                         VALUES (?, ?, TRUE, NOW())";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$manager_id, $message_text]);
            } else {
                // Send to specific recipients
                foreach ($recipient_ids as $to_id) {
                    $query = "INSERT INTO messages (from_id, to_id, message, created_at)
                             VALUES (?, ?, ?, NOW())";
                    $stmt = $pdo->prepare($query);
                    $stmt->execute([$manager_id, $to_id, $message_text]);
                }
            }
            
            sendJsonResponse(true, 'Message sent successfully', ['sent_at' => date('Y-m-d H:i:s')]);
            break;

        case 'get_schedule':
            // Get current schedule
            $query = "SELECT 
                        e.id,
                        e.name,
                        e.role,
                        e.status
                     FROM employees e
                     WHERE e.status = 'active'
                     ORDER BY e.name";
            
            $stmt = $pdo->query($query);
            $schedule = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            sendJsonResponse(true, 'Schedule retrieved', ['schedule' => $schedule]);
            break;

        case 'update_shift':
            // Update staff shift
            $employee_name = $input['employee_name'] ?? null;
            $shift_start = $input['shift_start'] ?? null;
            $shift_end = $input['shift_end'] ?? null;
            
            if (!$employee_name || !$shift_start || !$shift_end) {
                sendJsonResponse(false, 'Missing required fields');
            }
            
            // Create shifts table if it doesn't exist
            $createTable = "CREATE TABLE IF NOT EXISTS shifts (
                id INT PRIMARY KEY AUTO_INCREMENT,
                employee_id INT,
                employee_name VARCHAR(255),
                date DATE,
                shift_start TIME,
                shift_end TIME,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
            )";
            
            try {
                $pdo->query($createTable);
            } catch (Exception $e) {
                // Table might already exist
            }
            
            // Get employee ID from name
            $query = "SELECT id FROM employees WHERE name = ? LIMIT 1";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$employee_name]);
            $emp = $stmt->fetch();
            
            if (!$emp) {
                sendJsonResponse(false, 'Employee not found');
            }
            
            $employee_id = $emp['id'];
            
            // Check if shift exists for today
            $checkQuery = "SELECT id FROM shifts WHERE employee_id = ? AND DATE(date) = CURDATE()";
            $checkStmt = $pdo->prepare($checkQuery);
            $checkStmt->execute([$employee_id]);
            $existing = $checkStmt->fetch();
            
            if ($existing) {
                // Update existing shift
                $query = "UPDATE shifts SET shift_start = ?, shift_end = ?, updated_at = NOW() 
                         WHERE employee_id = ? AND DATE(date) = CURDATE()";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$shift_start, $shift_end, $employee_id]);
            } else {
                // Insert new shift
                $query = "INSERT INTO shifts (employee_id, employee_name, date, shift_start, shift_end) 
                         VALUES (?, ?, CURDATE(), ?, ?)";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$employee_id, $employee_name, $shift_start, $shift_end]);
            }
            
            sendJsonResponse(true, 'Shift updated successfully');
            break;

        case 'request_swap':
            // Request employee shift swap
            $employee1 = $input['employee1'] ?? null;
            $employee2 = $input['employee2'] ?? null;
            $reason = $input['reason'] ?? null;
            $request_manager_id = $input['manager_id'] ?? $manager_id;
            
            if (!$employee1 || !$employee2 || !$reason) {
                sendJsonResponse(false, 'Missing required fields');
            }
            
            // Create swap requests table if it doesn't exist
            $createTable = "CREATE TABLE IF NOT EXISTS swap_requests (
                id INT PRIMARY KEY AUTO_INCREMENT,
                employee1_name VARCHAR(255),
                employee2_name VARCHAR(255),
                reason TEXT,
                manager_id INT,
                status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (manager_id) REFERENCES employees(id) ON DELETE CASCADE
            )";
            
            try {
                $pdo->query($createTable);
            } catch (Exception $e) {
                // Table might already exist
            }
            
            $query = "INSERT INTO swap_requests (employee1_name, employee2_name, reason, manager_id) 
                     VALUES (?, ?, ?, ?)";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$employee1, $employee2, $reason, $request_manager_id]);
            
            sendJsonResponse(true, 'Swap request submitted successfully');
            break;

        case 'time_off_request':
            // Request time off for employee
            $employee_name = $input['employee_name'] ?? null;
            $start_date = $input['start_date'] ?? null;
            $end_date = $input['end_date'] ?? null;
            $reason = $input['reason'] ?? null;
            $request_manager_id = $input['manager_id'] ?? $manager_id;
            
            if (!$employee_name || !$start_date || !$end_date || !$reason) {
                sendJsonResponse(false, 'Missing required fields');
            }
            
            // Create time off requests table if it doesn't exist
            $createTable = "CREATE TABLE IF NOT EXISTS time_off_requests (
                id INT PRIMARY KEY AUTO_INCREMENT,
                employee_name VARCHAR(255),
                start_date DATE,
                end_date DATE,
                reason TEXT,
                manager_id INT,
                status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (manager_id) REFERENCES employees(id) ON DELETE CASCADE
            )";
            
            try {
                $pdo->query($createTable);
            } catch (Exception $e) {
                // Table might already exist
            }
            
            $query = "INSERT INTO time_off_requests (employee_name, start_date, end_date, reason, manager_id) 
                     VALUES (?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$employee_name, $start_date, $end_date, $reason, $request_manager_id]);
            
            sendJsonResponse(true, 'Time off request submitted successfully');
            break;

        default:
            sendJsonResponse(false, 'Invalid action');
    }

} catch (Exception $e) {
    sendJsonResponse(false, 'Error: ' . $e->getMessage());
}
?>

