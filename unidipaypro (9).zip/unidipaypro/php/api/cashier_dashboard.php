<?php
/**
 * Cashier Dashboard API
 * Handles cashier dashboard data and transactions
 */

require_once '../config/database.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$action = $_GET['action'] ?? '';
$cashier_id = $_GET['cashier_id'] ?? null;

try {
    switch ($action) {
        case 'stats':
            getCashierStats($cashier_id);
            break;
        
        case 'transactions':
            getTransactions($cashier_id);
            break;
        
        case 'drawer':
            getCashDrawer($cashier_id);
            break;
        
        case 'payment-methods':
            getPaymentMethods();
            break;
        
        default:
            sendResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    error_log("Cashier API Error: " . $e->getMessage());
    sendResponse(['error' => $e->getMessage()], 500);
}

/**
 * Get cashier statistics
 */
function getCashierStats($cashier_id) {
    global $pdo;
    
    try {
        // Total sales today
        $stmt = $pdo->query("
            SELECT SUM(total_amount) as total 
            FROM orders 
            WHERE DATE(created_at) = CURDATE() AND status = 'completed'
        ");
        $totalSales = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
        
        // Transaction count
        $stmt = $pdo->query("
            SELECT COUNT(*) as count 
            FROM orders 
            WHERE DATE(created_at) = CURDATE()
        ");
        $transactions = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        // Average transaction
        $avgTransaction = $transactions > 0 ? ($totalSales / $transactions) : 0;
        
        sendResponse([
            'success' => true,
            'stats' => [
                'total_sales' => round((float)$totalSales, 2),
                'transaction_count' => (int)$transactions,
                'average_transaction' => round((float)$avgTransaction, 2)
            ]
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Get recent transactions
 */
function getTransactions($cashier_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->query("
            SELECT 
                id,
                order_number,
                total_amount,
                payment_method,
                status,
                created_at
            FROM orders 
            WHERE DATE(created_at) = CURDATE()
            ORDER BY created_at DESC
            LIMIT 20
        ");
        
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        sendResponse([
            'success' => true,
            'transactions' => $transactions
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Get cash drawer info
 */
function getCashDrawer($cashier_id) {
    global $pdo;
    
    try {
        // Opening balance (from last close, or default)
        $openingBalance = 5000;
        
        // Cash received today
        $stmt = $pdo->query("
            SELECT SUM(total_amount) as total 
            FROM orders 
            WHERE DATE(created_at) = CURDATE() AND payment_method = 'cash'
        ");
        $cashReceived = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
        
        // Cash given (change, etc)
        $cashGiven = 450; // Mock data
        
        // Current balance
        $currentBalance = $openingBalance + $cashReceived - $cashGiven;
        
        sendResponse([
            'success' => true,
            'drawer' => [
                'opening_balance' => (float)$openingBalance,
                'cash_received' => round((float)$cashReceived, 2),
                'cash_given' => (float)$cashGiven,
                'current_balance' => round((float)$currentBalance, 2)
            ]
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Get payment method breakdown
 */
function getPaymentMethods() {
    global $pdo;
    
    try {
        $stmt = $pdo->query("
            SELECT 
                payment_method,
                COUNT(*) as count,
                SUM(total_amount) as total
            FROM orders 
            WHERE DATE(created_at) = CURDATE()
            GROUP BY payment_method
        ");
        
        $methods = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        sendResponse([
            'success' => true,
            'payment_methods' => $methods
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}
?>
