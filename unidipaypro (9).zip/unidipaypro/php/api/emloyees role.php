<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Set header
header('Content-Type: application/json');

// Include database config
require_once '../config/database.php';

// Check if user is logged in (skip for development/demo purposes with 'demo' param)
if (!isset($_SESSION['admin_id']) && !isset($_GET['demo'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Create employees table if it doesn't exist
try {
    // Check if table exists
    $checkTable = $pdo->query("SHOW TABLES LIKE 'employees'");
    if ($checkTable && $checkTable->rowCount() === 0) {
        $createTable = "
            CREATE TABLE IF NOT EXISTS employees (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                role ENUM('admin', 'manager', 'staff', 'cashier') NOT NULL DEFAULT 'staff',
                phone VARCHAR(20),
                status ENUM('active', 'inactive') DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_email (email),
                INDEX idx_role (role),
                INDEX idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";
        $pdo->exec($createTable);
        error_log("Employees table created successfully");
    }
} catch (PDOException $e) {
    error_log("Table creation error: " . $e->getMessage());
    // Don't fail - table might already exist
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

try {
    if (empty($action)) {
        throw new Exception('No action specified');
    }
    
    switch ($action) {
        case 'list':
            listEmployees($pdo);
            break;
        
        case 'get':
            getEmployee($pdo);
            break;
        
        case 'create':
            createEmployee($pdo);
            break;
        
        case 'update':
            updateEmployee($pdo);
            break;
        
        case 'delete':
            deleteEmployee($pdo);
            break;
        
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action: ' . $action]);
    }
    
} catch (PDOException $e) {
    error_log("Employee API Database Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error occurred']);
} catch (Exception $e) {
    error_log("Employee API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

/**
 * List all employees
 */
function listEmployees($conn) {
    try {
        $stmt = $conn->prepare("
            SELECT id, name, email, role, phone, status, created_at
            FROM employees
            ORDER BY created_at DESC
        ");
        $stmt->execute();
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'employees' => $employees
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Get single employee
 */
function getEmployee($conn) {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    if ($id === 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid employee ID']);
        return;
    }
    
    try {
        $stmt = $conn->prepare("
            SELECT id, name, email, role, phone, status, created_at
            FROM employees
            WHERE id = :id
        ");
        $stmt->execute(['id' => $id]);
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$employee) {
            echo json_encode(['success' => false, 'message' => 'Employee not found']);
            return;
        }
        
        echo json_encode([
            'success' => true,
            'employee' => $employee
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Create new employee
 */
function createEmployee($conn) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (empty($input['name']) || empty($input['email']) || empty($input['password']) || empty($input['role'])) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        return;
    }
    
    // Validate email format
    if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        return;
    }
    
    // Validate role
    $validRoles = ['admin', 'manager', 'staff', 'cashier'];
    if (!in_array($input['role'], $validRoles)) {
        echo json_encode(['success' => false, 'message' => 'Invalid role']);
        return;
    }
    
    // Check if email already exists
    try {
        $stmt = $conn->prepare("SELECT id FROM employees WHERE email = :email");
        $stmt->execute(['email' => $input['email']]);
        
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Email already exists']);
            return;
        }
        
        // Hash password
        $hashedPassword = password_hash($input['password'], PASSWORD_BCRYPT);
        $status = isset($input['status']) ? $input['status'] : 'active';
        $phone = isset($input['phone']) ? $input['phone'] : null;
        
        // Insert employee
        $stmt = $conn->prepare("
            INSERT INTO employees (name, email, password, role, phone, status, created_at, updated_at)
            VALUES (:name, :email, :password, :role, :phone, :status, NOW(), NOW())
        ");
        
        $stmt->execute([
            'name' => $input['name'],
            'email' => $input['email'],
            'password' => $hashedPassword,
            'role' => $input['role'],
            'phone' => $phone,
            'status' => $status
        ]);
        
        $employeeId = $conn->lastInsertId();
        
        echo json_encode([
            'success' => true,
            'message' => 'Employee created successfully',
            'employee_id' => $employeeId
        ]);
        
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Update employee
 */
function updateEmployee($conn) {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $input = json_decode(file_get_contents('php://input'), true);
    
    if ($id === 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid employee ID']);
        return;
    }
    
    // Validate required fields
    if (empty($input['name']) || empty($input['email']) || empty($input['role'])) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        return;
    }
    
    // Validate email format
    if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        return;
    }
    
    // Validate role
    $validRoles = ['admin', 'manager', 'staff', 'cashier'];
    if (!in_array($input['role'], $validRoles)) {
        echo json_encode(['success' => false, 'message' => 'Invalid role']);
        return;
    }
    
    try {
        // Check if employee exists
        $stmt = $conn->prepare("SELECT id FROM employees WHERE id = :id");
        $stmt->execute(['id' => $id]);
        
        if (!$stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Employee not found']);
            return;
        }
        
        // Check if new email is already used by another employee
        $stmt = $conn->prepare("SELECT id FROM employees WHERE email = :email AND id != :id");
        $stmt->execute(['email' => $input['email'], 'id' => $id]);
        
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Email already exists']);
            return;
        }
        
        $status = isset($input['status']) ? $input['status'] : 'active';
        $phone = isset($input['phone']) ? $input['phone'] : null;
        
        // Update employee
        $stmt = $conn->prepare("
            UPDATE employees 
            SET name = :name, email = :email, role = :role, phone = :phone, status = :status, updated_at = NOW()
            WHERE id = :id
        ");
        
        $stmt->execute([
            'name' => $input['name'],
            'email' => $input['email'],
            'role' => $input['role'],
            'phone' => $phone,
            'status' => $status,
            'id' => $id
        ]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Employee updated successfully'
        ]);
        
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Delete employee
 */
function deleteEmployee($conn) {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    if ($id === 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid employee ID']);
        return;
    }
    
    try {
        // Check if employee exists
        $stmt = $conn->prepare("SELECT id FROM employees WHERE id = :id");
        $stmt->execute(['id' => $id]);
        
        if (!$stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Employee not found']);
            return;
        }
        
        // Delete employee
        $stmt = $conn->prepare("DELETE FROM employees WHERE id = :id");
        $stmt->execute(['id' => $id]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Employee deleted successfully'
        ]);
        
    } catch (Exception $e) {
        throw $e;
    }
}
?>
