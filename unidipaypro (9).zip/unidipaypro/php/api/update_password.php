<?php
require_once '../config/database.php';

$hash = password_hash('test123', PASSWORD_BCRYPT);
$stmt = $pdo->prepare('UPDATE employees SET password = ? WHERE email = ?');
$stmt->execute([$hash, 'jennie@unidipay.com']);

echo json_encode([
    'success' => true,
    'message' => 'Password updated to test123',
    'hash' => $hash
]);
?>
