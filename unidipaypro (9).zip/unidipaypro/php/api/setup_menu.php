<?php
require_once __DIR__ . '/../config/database.php';

try {
    // Check if table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'menu_items'");
    $result = $stmt->fetch();
    
    if ($result) {
        echo "Table exists\n";
        // Get count
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM menu_items");
        $data = $stmt->fetch();
        echo "Items: " . $data['count'] . "\n";
    } else {
        echo "Table does not exist, creating...\n";
        // Create table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS menu_items (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(100) NOT NULL,
                category VARCHAR(50) NOT NULL,
                price DECIMAL(10,2) NOT NULL,
                description TEXT,
                image_url VARCHAR(255),
                available BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        ");
        echo "Table created successfully\n";
        
        // Insert sample data
        $pdo->exec("
            INSERT INTO menu_items (name, category, price, description, image_url, available) VALUES
            ('Fried Chicken', 'meals', 150.00, 'Crispy fried chicken with rice', 'https://via.placeholder.com/200?text=Fried+Chicken', 1),
            ('Carbonara Pasta', 'meals', 180.00, 'Creamy carbonara pasta with bacon', 'https://via.placeholder.com/200?text=Carbonara', 1),
            ('Caesar Salad', 'meals', 120.00, 'Fresh caesar salad with croutons', 'https://via.placeholder.com/200?text=Caesar+Salad', 1),
            ('Iced Coffee', 'drinks', 80.00, 'Cold brew iced coffee', 'https://via.placeholder.com/200?text=Iced+Coffee', 1),
            ('Mango Juice', 'drinks', 90.00, 'Fresh mango juice', 'https://via.placeholder.com/200?text=Mango+Juice', 1),
            ('French Fries', 'snacks', 60.00, 'Crispy golden french fries', 'https://via.placeholder.com/200?text=French+Fries', 1),
            ('Onion Rings', 'snacks', 75.00, 'Golden fried onion rings', 'https://via.placeholder.com/200?text=Onion+Rings', 1),
            ('Chocolate Cake', 'desserts', 120.00, 'Rich chocolate cake slice', 'https://via.placeholder.com/200?text=Chocolate+Cake', 1),
            ('Ice Cream', 'desserts', 85.00, 'Vanilla ice cream scoop', 'https://via.placeholder.com/200?text=Ice+Cream', 1)
        ");
        echo "Sample data inserted successfully\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
