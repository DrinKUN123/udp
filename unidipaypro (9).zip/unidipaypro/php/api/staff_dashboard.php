<?php
/**
 * Staff Dashboard API
 * Handles staff member dashboard data
 */

require_once '../config/database.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$action = $_GET['action'] ?? '';
$employee_id = $_GET['employee_id'] ?? null;

try {
    switch ($action) {
        case 'stats':
            getStaffStats($employee_id);
            break;
        
        case 'shift':
            getShiftInfo($employee_id);
            break;
        
        case 'orders':
            getStaffOrders($employee_id);
            break;
        
        case 'profile':
            getStaffProfile($employee_id);
            break;
        
        case 'tasks':
            getTasks($employee_id);
            break;
        
        case 'schedule':
            getSchedule($employee_id);
            break;
        
        default:
            sendResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    error_log("Staff API Error: " . $e->getMessage());
    sendResponse(['error' => $e->getMessage()], 500);
}

/**
 * Get staff statistics
 */
function getStaffStats($employee_id) {
    global $pdo;
    
    if (!$employee_id) {
        sendResponse(['error' => 'Employee ID required'], 400);
        return;
    }
    
    try {
        // Orders prepared today
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM orders WHERE assigned_staff = ? AND DATE(created_at) = CURDATE() AND status = 'completed'");
        $stmt->execute([$employee_id]);
        $prepared = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        // Active orders
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM orders WHERE assigned_staff = ? AND status = 'active'");
        $stmt->execute([$employee_id]);
        $active = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        // Total shift hours
        $shiftHours = 8; // Default 8 hour shift
        
        sendResponse([
            'success' => true,
            'stats' => [
                'orders_prepared' => (int)$prepared,
                'active_orders' => (int)$active,
                'shift_hours' => $shiftHours
            ]
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Get shift information
 */
function getShiftInfo($employee_id) {
    global $pdo;
    
    if (!$employee_id) {
        sendResponse(['error' => 'Employee ID required'], 400);
        return;
    }
    
    // Default shift times (can be customized per employee)
    $shiftStart = '10:00 AM';
    $shiftEnd = '6:00 PM';
    $breakTaken = false;
    
    sendResponse([
        'success' => true,
        'shift' => [
            'start_time' => $shiftStart,
            'end_time' => $shiftEnd,
            'break_taken' => $breakTaken,
            'current_time' => date('H:i A')
        ]
    ]);
}

/**
 * Get staff orders
 */
function getStaffOrders($employee_id) {
    global $pdo;
    
    if (!$employee_id) {
        sendResponse(['error' => 'Employee ID required'], 400);
        return;
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT 
                id,
                order_number,
                status,
                total_amount,
                created_at,
                completed_at
            FROM orders 
            WHERE assigned_staff = ? 
            ORDER BY created_at DESC 
            LIMIT 10
        ");
        $stmt->execute([$employee_id]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        sendResponse([
            'success' => true,
            'orders' => $orders
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Get staff profile
 */
function getStaffProfile($employee_id) {
    global $pdo;
    
    if (!$employee_id) {
        sendResponse(['error' => 'Employee ID required'], 400);
        return;
    }
    
    try {
        $stmt = $pdo->prepare("SELECT id, name, email, role, phone FROM employees WHERE id = ?");
        $stmt->execute([$employee_id]);
        $profile = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$profile) {
            sendResponse(['error' => 'Profile not found'], 404);
            return;
        }
        
        sendResponse([
            'success' => true,
            'profile' => $profile
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Get tasks for employee
 */
function getTasks($employee_id) {
    // Sample tasks data
    $tasks = [
        [
            'id' => 1,
            'task_name' => 'Restock ingredients and supplies',
            'priority' => 'High',
            'completed' => false
        ],
        [
            'id' => 2,
            'task_name' => 'Prepare mise en place for lunch rush',
            'priority' => 'High',
            'completed' => false
        ],
        [
            'id' => 3,
            'task_name' => 'Review special orders from manager',
            'priority' => 'Medium',
            'completed' => false
        ],
        [
            'id' => 4,
            'task_name' => 'Clean and sanitize workstation',
            'priority' => 'Medium',
            'completed' => false
        ],
        [
            'id' => 5,
            'task_name' => 'Check equipment functionality',
            'priority' => 'Low',
            'completed' => false
        ]
    ];
    
    sendResponse(['success' => true, 'tasks' => $tasks]);
}

/**
 * Get employee schedule
 */
function getSchedule($employee_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT id, employee_id, employee_name, date, shift_start, shift_end
            FROM shifts
            WHERE employee_id = ? AND date >= CURDATE()
            ORDER BY date ASC
            LIMIT 1
        ");
        $stmt->execute([$employee_id]);
        $schedule = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$schedule) {
            // Return default schedule if none found
            $schedule = [
                'id' => 0,
                'employee_id' => $employee_id,
                'date' => date('Y-m-d'),
                'shift_start' => '10:00:00',
                'shift_end' => '18:00:00'
            ];
        }
        
        sendResponse(['success' => true, 'schedule' => $schedule]);
    } catch (Exception $e) {
        throw $e;
    }
}
?>
