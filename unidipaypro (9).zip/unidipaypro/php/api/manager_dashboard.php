<?php
/**
 * Manager Dashboard API
 * Handles manager dashboard data
 */

require_once '../config/database.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$action = $_GET['action'] ?? '';
$manager_id = $_GET['manager_id'] ?? null;

try {
    switch ($action) {
        case 'stats':
            getManagerStats();
            break;
        
        case 'team':
            getTeamStatus($manager_id);
            break;
        
        case 'orders':
            getOrdersToday();
            break;
        
        case 'performance':
            getPerformanceMetrics();
            break;
        
        default:
            sendResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    error_log("Manager API Error: " . $e->getMessage());
    sendResponse(['error' => $e->getMessage()], 500);
}

/**
 * Get manager statistics
 */
function getManagerStats() {
    global $pdo;
    
    try {
        // Total orders today
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = CURDATE()");
        $totalOrders = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        // Completed orders
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = CURDATE() AND status = 'completed'");
        $completed = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        // Staff on duty
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM employees WHERE role IN ('staff', 'cashier') AND status = 'active'");
        $staffOnDuty = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        // Average order time (in minutes)
        $stmt = $pdo->query("
            SELECT AVG(TIMESTAMPDIFF(MINUTE, created_at, completed_at)) as avg_time 
            FROM orders 
            WHERE DATE(created_at) = CURDATE() AND status = 'completed'
        ");
        $avgTime = $stmt->fetch(PDO::FETCH_ASSOC)['avg_time'] ?? 0;
        
        sendResponse([
            'success' => true,
            'stats' => [
                'total_orders' => (int)$totalOrders,
                'orders_completed' => (int)$completed,
                'staff_on_duty' => (int)$staffOnDuty,
                'avg_order_time' => round((float)$avgTime, 1)
            ]
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Get team status
 */
function getTeamStatus($manager_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->query("
            SELECT 
                id,
                name,
                role,
                status,
                email
            FROM employees 
            WHERE role IN ('staff', 'cashier') AND status = 'active'
            ORDER BY name ASC
        ");
        
        $team = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Add status info
        foreach ($team as &$member) {
            $member['status_badge'] = match($member['status']) {
                'active' => 'Active',
                default => 'Offline'
            };
            $member['shift_time'] = '2h 30m'; // Mock data
        }
        
        sendResponse([
            'success' => true,
            'team' => $team
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Get orders today
 */
function getOrdersToday() {
    global $pdo;
    
    try {
        $stmt = $pdo->query("
            SELECT 
                id,
                order_number,
                total_amount,
                status,
                payment_method,
                created_at
            FROM orders 
            WHERE DATE(created_at) = CURDATE()
            ORDER BY created_at DESC
            LIMIT 20
        ");
        
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        sendResponse([
            'success' => true,
            'orders' => $orders
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Get performance metrics
 */
function getPerformanceMetrics() {
    global $pdo;
    
    try {
        // Orders per hour
        $stmt = $pdo->query("
            SELECT COUNT(*) / (HOUR(MAX(created_at)) - HOUR(MIN(created_at)) + 1) as per_hour
            FROM orders 
            WHERE DATE(created_at) = CURDATE()
        ");
        $ordersPerHour = $stmt->fetch(PDO::FETCH_ASSOC)['per_hour'] ?? 0;
        
        // Accuracy rate (completed vs total)
        $stmt = $pdo->query("
            SELECT 
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
                COUNT(*) as total
            FROM orders 
            WHERE DATE(created_at) = CURDATE()
        ");
        $accuracy = $stmt->fetch(PDO::FETCH_ASSOC);
        $accuracyRate = $accuracy['total'] > 0 ? ($accuracy['completed'] / $accuracy['total'] * 100) : 0;
        
        sendResponse([
            'success' => true,
            'metrics' => [
                'orders_per_hour' => round((float)$ordersPerHour, 2),
                'accuracy_rate' => round((float)$accuracyRate, 1),
                'customer_satisfaction' => 95.5 // Mock data
            ]
        ]);
    } catch (Exception $e) {
        throw $e;
    }
}
?>
