<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Parse JSON or form data
$input = [];
if ($_SERVER['CONTENT_TYPE'] === 'application/json' || strpos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
} else {
    $input = $_POST;
}

$action = $_GET['action'] ?? '';
$employee_id = $_SESSION['employee_id'] ?? $_GET['employee_id'] ?? null;

function sendJsonResponse($success, $message = '', $data = []) {
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

try {
    // Connect to database using PDO
    $pdo = new PDO(
        "mysql:host=localhost;dbname=unidipay_db;charset=utf8mb4",
        "root",
        "",
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

    switch ($action) {
        case 'save_preferences':
            // Save employee preferences to database
            $notification_setting = $input['notification_setting'] ?? 'all';
            $break_time = $input['break_time'] ?? '12:00';
            $task_reminder = $input['task_reminder'] ?? '30';
            $language = $input['language'] ?? 'en';
            
            if (!$employee_id) {
                sendJsonResponse(false, 'Employee ID required');
            }
            
            // Create preferences table if it doesn't exist
            $createTable = "CREATE TABLE IF NOT EXISTS staff_preferences (
                id INT PRIMARY KEY AUTO_INCREMENT,
                employee_id INT UNIQUE,
                notification_setting ENUM('all', 'important', 'none') DEFAULT 'all',
                break_time TIME DEFAULT '12:00:00',
                task_reminder INT DEFAULT 30,
                language VARCHAR(10) DEFAULT 'en',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
            )";
            
            try {
                $pdo->query($createTable);
            } catch (Exception $e) {
                // Table might already exist
            }
            
            // Check if preferences exist for employee
            $checkQuery = "SELECT id FROM staff_preferences WHERE employee_id = ?";
            $checkStmt = $pdo->prepare($checkQuery);
            $checkStmt->execute([$employee_id]);
            $existing = $checkStmt->fetch();
            
            if ($existing) {
                // Update existing preferences
                $query = "UPDATE staff_preferences SET notification_setting = ?, break_time = ?, task_reminder = ?, language = ?, updated_at = NOW() 
                         WHERE employee_id = ?";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$notification_setting, $break_time, $task_reminder, $language, $employee_id]);
            } else {
                // Insert new preferences
                $query = "INSERT INTO staff_preferences (employee_id, notification_setting, break_time, task_reminder, language) 
                         VALUES (?, ?, ?, ?, ?)";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$employee_id, $notification_setting, $break_time, $task_reminder, $language]);
            }
            
            sendJsonResponse(true, 'Preferences saved successfully', [
                'notification_setting' => $notification_setting,
                'break_time' => $break_time,
                'task_reminder' => $task_reminder,
                'language' => $language
            ]);
            break;

        case 'get_preferences':
            // Get employee preferences
            if (!$employee_id) {
                sendJsonResponse(false, 'Employee ID required');
            }
            
            $query = "SELECT notification_setting, break_time, task_reminder, language 
                     FROM staff_preferences WHERE employee_id = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$employee_id]);
            $prefs = $stmt->fetch();
            
            if ($prefs) {
                sendJsonResponse(true, 'Preferences retrieved', $prefs);
            } else {
                // Return defaults if no preferences set
                sendJsonResponse(true, 'Preferences not set, using defaults', [
                    'notification_setting' => 'all',
                    'break_time' => '12:00:00',
                    'task_reminder' => 30,
                    'language' => 'en'
                ]);
            }
            break;

        case 'update_notification':
            // Update only notification settings
            $notification_setting = $input['notification_setting'] ?? 'all';
            
            if (!$employee_id) {
                sendJsonResponse(false, 'Employee ID required');
            }
            
            $query = "UPDATE staff_preferences SET notification_setting = ?, updated_at = NOW() 
                     WHERE employee_id = ?";
            $stmt = $pdo->prepare($query);
            $result = $stmt->execute([$notification_setting, $employee_id]);
            
            if ($stmt->rowCount() > 0) {
                sendJsonResponse(true, 'Notification setting updated');
            } else {
                // Insert if not exists
                $query = "INSERT INTO staff_preferences (employee_id, notification_setting) VALUES (?, ?)";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$employee_id, $notification_setting]);
                sendJsonResponse(true, 'Notification setting saved');
            }
            break;

        case 'update_break_time':
            // Update only break time
            $break_time = $input['break_time'] ?? '12:00';
            
            if (!$employee_id) {
                sendJsonResponse(false, 'Employee ID required');
            }
            
            $query = "UPDATE staff_preferences SET break_time = ?, updated_at = NOW() 
                     WHERE employee_id = ?";
            $stmt = $pdo->prepare($query);
            $result = $stmt->execute([$break_time, $employee_id]);
            
            if ($stmt->rowCount() > 0) {
                sendJsonResponse(true, 'Break time updated');
            } else {
                // Insert if not exists
                $query = "INSERT INTO staff_preferences (employee_id, break_time) VALUES (?, ?)";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$employee_id, $break_time]);
                sendJsonResponse(true, 'Break time saved');
            }
            break;

        case 'update_task_reminder':
            // Update only task reminder
            $task_reminder = $input['task_reminder'] ?? 30;
            
            if (!$employee_id) {
                sendJsonResponse(false, 'Employee ID required');
            }
            
            $query = "UPDATE staff_preferences SET task_reminder = ?, updated_at = NOW() 
                     WHERE employee_id = ?";
            $stmt = $pdo->prepare($query);
            $result = $stmt->execute([$task_reminder, $employee_id]);
            
            if ($stmt->rowCount() > 0) {
                sendJsonResponse(true, 'Task reminder updated');
            } else {
                // Insert if not exists
                $query = "INSERT INTO staff_preferences (employee_id, task_reminder) VALUES (?, ?)";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$employee_id, $task_reminder]);
                sendJsonResponse(true, 'Task reminder saved');
            }
            break;

        case 'update_language':
            // Update only language
            $language = $input['language'] ?? 'en';
            
            if (!$employee_id) {
                sendJsonResponse(false, 'Employee ID required');
            }
            
            $query = "UPDATE staff_preferences SET language = ?, updated_at = NOW() 
                     WHERE employee_id = ?";
            $stmt = $pdo->prepare($query);
            $result = $stmt->execute([$language, $employee_id]);
            
            if ($stmt->rowCount() > 0) {
                sendJsonResponse(true, 'Language updated');
            } else {
                // Insert if not exists
                $query = "INSERT INTO staff_preferences (employee_id, language) VALUES (?, ?)";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$employee_id, $language]);
                sendJsonResponse(true, 'Language saved');
            }
            break;

        default:
            sendJsonResponse(false, 'Invalid action');
    }

} catch (Exception $e) {
    sendJsonResponse(false, 'Error: ' . $e->getMessage());
}
?>
