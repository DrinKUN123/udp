# UniDiPay - Role-Based Access Control Implementation

## Overview
This implementation adds role-based access control (RBAC) to the UniDiPay system with three roles:
- **Manager**: Full access to all admin pages
- **Staff**: Access to Menu and Orders
- **Cashier**: Access to Orders and Menu

## Files Modified/Created

### 1. Database Setup
- **`database_setup.sql`** - SQL script to create employees table with roles
- **`setup_employees_table.php`** - PHP script for automated table creation

### 2. Backend API Files

#### `php/api/EmloyeeRoles.php` (NEW)
- Complete CRUD operations for employee management
- Role validation (manager, staff, cashier)
- Only managers can create/update/delete employees
- Password hashing for security

#### `php/api/auth.php` (UPDATED)
- Modified `handleLogin()` to check employees table first
- Stores user role in session: `$_SESSION['admin_role']`
- Fallback to admins table for backwards compatibility
- `checkSession()` returns user role in response

### 3. Frontend Files

#### `index.html` (UPDATED)
- Role-based redirect after login:
  - Manager → dashboard.html
  - Staff → menu.html
  - Cashier → orders.html
- Updated login logic with `getRoleBasedRedirect()` function

#### `EmloyeeRoles.html` (COMPLETELY REWRITTEN)
- Employee management interface (Manager only)
- Create new employee accounts with roles
- View all employees in table format
- Edit employee details
- Delete employees
- Shows role badges and status indicators

#### `js/main.js` (UPDATED)
- **`getUserRole()`** - Get current user's role
- **`checkRoleBasedAccess()`** - Verify page access and hide nav items
- **`updateNavigation(role)`** - Hide unauthorized navigation links
- **`canManageEmployees()`** - Check if user is manager
- **`protectAdminPage()`** - Protect manager-only pages
- Updated exports in `window.UniDiPay`

#### `css/style.css` (UPDATED)
- Employee management form styles
- Table styles for employee listing
- Badge styles for roles (Manager/Staff/Cashier)
- Status badge styles (Active/Inactive)
- Modal dialog styles
- Loading and empty state styles
- Form message styles (success/error)
- Password toggle wrapper styles

## Role-Based Access Matrix

### Manager Role
- **Accessible Pages**: 
  - dashboard.html
  - EmloyeeRoles.html
  - menu.html
  - nfc.html
  - orders.html
  - reports.html
  - users.html

### Staff Role
- **Accessible Pages**:
  - menu.html
  - orders.html

### Cashier Role
- **Accessible Pages**:
  - orders.html
  - menu.html

## Implementation Steps

### 1. Database Setup
Execute one of these options:

**Option A: Using SQL file**
```sql
-- Copy and run database_setup.sql in phpMyAdmin or MySQL client
```

**Option B: Using PHP setup script**
```
Visit: http://localhost/unidipaypro/setup_employees_table.php
```

### 2. Create Test Accounts (Using Manager Account)
1. Login with existing admin account (will be treated as Manager)
2. Go to Employee Roles page
3. Create test accounts:
   - Staff Account: email@staff.com, role: staff
   - Cashier Account: email@cashier.com, role: cashier

### 3. Test the System
1. Login with each role to verify correct page redirection
2. Verify navigation shows only allowed pages
3. Verify page access is restricted
4. Test employee management (Manager only)

## Security Features

1. **Role-Based Access Control**
   - Server-side validation in auth.php
   - Client-side navigation hiding (UX improvement)
   - Automatic redirect if unauthorized access attempted

2. **Password Security**
   - Passwords hashed with bcrypt (password_hash)
   - Verified with password_verify
   - Manager can reset employee passwords

3. **Session Management**
   - Role stored in session
   - Session validation on every page
   - Logout clears all session data

4. **Input Validation**
   - Email format validation
   - Required field validation
   - Role enum validation
   - Prepared statements to prevent SQL injection

## API Endpoints

### Authentication
- `POST /php/api/auth.php?action=login` - Login user
- `POST /php/api/auth.php?action=register` - Register admin (legacy)
- `GET /php/api/auth.php?action=check` - Check session
- `GET /php/api/auth.php?action=logout` - Logout

### Employee Management (Manager only)
- `GET /php/api/EmloyeeRoles.php?action=all` - Get all employees
- `GET /php/api/EmloyeeRoles.php?action=single&id=X` - Get employee by ID
- `POST /php/api/EmloyeeRoles.php` - Create employee
- `PUT /php/api/EmloyeeRoles.php` - Update employee
- `DELETE /php/api/EmloyeeRoles.php?action=delete&id=X` - Delete employee

## Response Format

### Login Success
```json
{
  "success": true,
  "admin": {
    "id": 1,
    "name": "User Name",
    "email": "user@email.com",
    "role": "manager"
  }
}
```

### Login Error
```json
{
  "error": "Invalid email or password"
}
```

### Employee Created
```json
{
  "success": true,
  "message": "Employee created successfully",
  "employee": {
    "id": 5,
    "name": "John Doe",
    "email": "john@example.com",
    "role": "staff",
    "status": "active"
  }
}
```

## Troubleshooting

### Database Connection Error
- Verify database credentials in `php/config/database.php`
- Ensure MySQL server is running
- Check if database `unidipay_db` exists

### Employees Table Not Created
- Run `setup_employees_table.php` from browser
- Or manually execute `database_setup.sql`

### Login Returns "Invalid email or password"
- Ensure employee account exists in `employees` table
- Check that password is correct
- Verify employee status is "active"

### Navigation Not Hiding
- Clear browser cache
- Verify role is correctly set in localStorage
- Check browser console for JavaScript errors

### Page Access Denied
- Verify user role has access to the page
- Check access matrix above
- Logout and login again

## File Structure
```
unidipaypro/
├── index.html                    (Login page - UPDATED)
├── dashboard.html                (Manager only)
├── EmloyeeRoles.html            (Manager only - NEW)
├── menu.html                    (Staff, Manager, Cashier)
├── orders.html                  (Staff, Manager, Cashier)
├── nfc.html                     (Manager only)
├── reports.html                 (Manager only)
├── users.html                   (Manager only)
├── php/
│   ├── api/
│   │   ├── auth.php            (UPDATED - role support)
│   │   └── EmloyeeRoles.php    (NEW - employee management)
│   └── config/
│       └── database.php         (No changes needed)
├── js/
│   └── main.js                  (UPDATED - RBAC functions)
├── css/
│   └── style.css                (UPDATED - new styles)
├── database_setup.sql           (NEW)
└── setup_employees_table.php    (NEW)
```

## Testing Credentials

### Manager Account (Create in Employee Roles page)
- Email: manager@test.com
- Role: Manager
- Access: All pages

### Staff Account (Create in Employee Roles page)
- Email: staff@test.com
- Role: Staff
- Access: menu.html, orders.html

### Cashier Account (Create in Employee Roles page)
- Email: cashier@test.com
- Role: Cashier
- Access: orders.html, menu.html

## Maintenance Notes

1. **Backup employees table regularly**
2. **Monitor access logs for unauthorized attempts**
3. **Review and update role assignments periodically**
4. **Test role changes in a staging environment first**

## Future Enhancements

1. Add role-based API endpoint protection
2. Implement audit logging for employee management
3. Add permission-based access (beyond roles)
4. Implement employee activity tracking
5. Add role templates for easier management
6. Implement team/department structure
