# RBAC System - Quick Testing Guide

## ⚡ Quick Start

### 1. Access the System
```
URL: http://localhost/unidipaypro/
```

### 2. Login Credentials (You need to create these first)

**Create test accounts using the database:**

```sql
-- Manager account
INSERT INTO employees (name, email, password, role, status, created_at, updated_at)
VALUES ('Manager Name', 'manager@test.com', '$2y$10$hashhere', 'manager', 'active', NOW(), NOW());

-- Staff account
INSERT INTO employees (name, email, password, role, status, created_at, updated_at)
VALUES ('Staff Name', 'staff@test.com', '$2y$10$hashhere', 'staff', 'active', NOW(), NOW());

-- Cashier account
INSERT INTO employees (name, email, password, role, status, created_at, updated_at)
VALUES ('Cashier Name', 'cashier@test.com', '$2y$10$hashhere', 'cashier', 'active', NOW(), NOW());
```

**OR use PHP to hash passwords:**

```php
<?php
// In php/api/EmloyeeRoles.php or standalone
$plainPassword = "password123";
$hashedPassword = password_hash($plainPassword, PASSWORD_BCRYPT);
echo $hashedPassword; // Copy this hash to database
?>
```

### 3. Test Each Role

#### Manager Test
```
Email: manager@test.com
Password: (your test password)

Expected Results:
✓ Redirects to dashboard.html
✓ Shows all 7 navigation items:
  • Dashboard
  • User Management
  • Employee Roles
  • NFC Management
  • Menu Management
  • Order Monitoring
  • Records & Reports
✓ Console shows: "Navigation filtered for role: manager, showing 7 pages"
```

#### Staff Test
```
Email: staff@test.com
Password: (your test password)

Expected Results:
✓ Redirects to menu.html
✓ Shows ONLY 2 navigation items:
  • Menu Management
  • Order Monitoring
✓ Other items are hidden (display: none)
✓ Console shows: "Navigation filtered for role: staff, showing 2 pages"
```

#### Cashier Test
```
Email: cashier@test.com
Password: (your test password)

Expected Results:
✓ Redirects to orders.html
✓ Shows ONLY 4 navigation items:
  • NFC Management
  • Menu Management
  • Order Monitoring
  • Records & Reports
✓ Dashboard, Users, Employee Roles are hidden
✓ Console shows: "Navigation filtered for role: cashier, showing 4 pages"
```

---

## 🔍 Verification Steps

### Browser Console Check
```
F12 → Console tab

Look for these messages:
- "Navigation filtered for role: [role], showing X pages"
- Should appear when page loads
- Should show correct role and page count
```

### DevTools Element Inspector
```
F12 → Elements tab

Right-click a hidden navigation item (e.g., Dashboard for staff)
Select "Inspect"

Verify:
✓ Class attribute includes "hidden"
✓ Style attribute has "display: none !important"
✓ In Computed Styles: "display: none" from multiple sources
```

### Local Storage Check
```
F12 → Storage → Local Storage

Look for key: "admin"

Should show:
{
  "id": "...",
  "name": "...",
  "email": "...",
  "role": "manager|staff|cashier"
}
```

### Direct URL Test
```
1. Login as staff user
2. In address bar: type dashboard.html and press Enter
3. Verify: Redirects back to menu.html
4. Check console for: "Access Denied: staff cannot access dashboard.html"
```

---

## 📊 Navigation Matrix Summary

```
┌─────────────────────────────────────────────────────────────────┐
│ MANAGER (7 pages)                                               │
├─────────────────────────────────────────────────────────────────┤
│ ✓ Dashboard (default)   │ ✓ User Management                    │
│ ✓ Employee Roles        │ ✓ NFC Management                     │
│ ✓ Menu Management       │ ✓ Order Monitoring                   │
│ ✓ Records & Reports     │                                       │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ STAFF (2 pages)                                                 │
├─────────────────────────────────────────────────────────────────┤
│ ✓ Menu Management       │ ✓ Order Monitoring (default)         │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CASHIER (4 pages)                                               │
├─────────────────────────────────────────────────────────────────┤
│ ✓ NFC Management        │ ✓ Menu Management                    │
│ ✓ Order Monitoring (default) │ ✓ Records & Reports             │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🐛 Troubleshooting

### Issue: "All navigation items are visible"
**Possible Causes:**
1. Role not stored in localStorage
2. CSS rule not applied
3. JavaScript not executing

**Solutions:**
```
1. Check F12 → Storage → Local Storage for "admin" key
2. Check F12 → Elements, search for .nav-item.hidden CSS class
3. Check F12 → Console for errors
4. Try Ctrl+Shift+R (hard refresh)
5. Check browser compatibility (use Chrome/Firefox)
```

### Issue: "Login not working"
**Possible Causes:**
1. Database not set up
2. auth.php not accessible
3. Wrong credentials

**Solutions:**
```
1. Run: setup_employees_table.php in browser
2. Check network request to auth.php in F12 → Network
3. Verify employee exists in database
4. Check password is correctly hashed (bcrypt)
```

### Issue: "Redirecting to wrong page"
**Possible Causes:**
1. Default page mapping incorrect
2. Role not recognized

**Solutions:**
```
1. Check localStorage for correct role
2. Check default page mapping in checkRoleBasedAccess():
   - manager → dashboard.html
   - staff → menu.html
   - cashier → orders.html
3. Try logout and login again
```

### Issue: "Page says 'Access Denied' but page shouldn't be restricted"
**Possible Causes:**
1. Page name doesn't match allowed pages list
2. HTML filename wrong

**Solutions:**
```
1. Check exact filename in address bar
2. Verify filename matches in access matrix
3. Check for typos (.html extension, exact case)
4. Verify allowed pages in js/main.js accessMatrix
```

---

## 📋 Files to Check

**If Login Doesn't Work:**
- `php/api/auth.php` - Check database connection
- `php/config/database.php` - Check credentials
- Database - Verify employees table exists

**If Navigation Not Filtering:**
- `js/main.js` - Check updateNavigation() function (line 288)
- `css/style.css` - Check .nav-item.hidden rule (line 319)
- `dashboard.html` - Check protectPage() call (line 148)
- `menu.html` - Check protectPage() call (line 135)
- `orders.html` - Check protectPage() call (line 323)
- `reports.html` - Check protectPage() call (line 149)
- `users.html` - Check protectPage() call (line 176)

**If Direct URL Access Not Blocked:**
- `js/main.js` - Check checkRoleBasedAccess() (line 236)
- Check window.location.href redirect is working
- Check console for "Access Denied" message

---

## 🔧 Manual Setup Steps

If you haven't set up the database yet:

### 1. Create Database
```sql
CREATE DATABASE unidipaypro;
USE unidipaypro;
```

### 2. Create employees Table
```sql
CREATE TABLE employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('manager', 'staff', 'cashier') DEFAULT 'staff',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 3. Create Test Users
```php
<?php
// Save as test_setup.php and access via browser

require_once 'php/config/database.php';

// Hash password
$password = password_hash("Test@123", PASSWORD_BCRYPT);

// Create test users
$users = [
    ['Manager Test', 'manager@test.com', 'manager'],
    ['Staff Test', 'staff@test.com', 'staff'],
    ['Cashier Test', 'cashier@test.com', 'cashier']
];

$conn = new mysqli($servername, $username, $password_db, $dbname);

foreach ($users as $user) {
    $stmt = $conn->prepare("INSERT INTO employees (name, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $user[0], $user[1], $password, $user[2]);
    if ($stmt->execute()) {
        echo "Created: " . $user[0] . "<br>";
    }
}

$stmt->close();
$conn->close();
echo "Setup complete!";
?>
```

Then visit: `http://localhost/unidipaypro/test_setup.php`

---

## ✅ Final Checklist Before Testing

- [ ] XAMPP/Apache running
- [ ] MySQL running
- [ ] Database `unidipaypro` exists
- [ ] `employees` table created
- [ ] Test users created (manager, staff, cashier)
- [ ] Can access http://localhost/unidipaypro/ in browser
- [ ] login page loads
- [ ] Database password updated in php/config/database.php (if needed)

---

## 💡 Tips

1. **Use Incognito/Private mode** to test different roles without clearing cache
2. **Keep DevTools open** (F12) to see console messages
3. **Check Network tab** if login doesn't work to see if auth.php request succeeds
4. **Use different browser tabs** for different roles
5. **Hard refresh** (Ctrl+Shift+R) if CSS changes don't apply

---

## 📞 Need Help?

Check these in order:
1. Browser console (F12) for error messages
2. Network tab (F12) to see if requests succeed
3. Local storage (F12 → Storage) for role data
4. Database to verify test users exist
5. php/config/database.php for correct credentials

---

**Ready to test!** 🚀

Start with the Manager login to verify the system works, then test Staff and Cashier roles.
