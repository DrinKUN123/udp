<?php
/**
 * Reports API
 * Analytics, daily sales, transaction logs, CSV export
 */

require_once '../config/database.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

if (!isLoggedIn()) {
    sendResponse(['error' => 'Unauthorized'], 401);
}

$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'daily_sales':
            getDailySales();
            break;
            
        case 'transactions':
            getTransactions();
            break;
            
        case 'reloads':
            getReloads();
            break;
            
        case 'dashboard_stats':
            getDashboardStats();
            break;
            
        case 'export_csv':
            exportCSV();
            break;
            
        default:
            sendResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    sendResponse(['error' => $e->getMessage()], 500);
}

/**
 * Get daily sales report
 */
function getDailySales() {
    global $pdo;
    
    $date = $_GET['date'] ?? date('Y-m-d');
    
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_orders,
            COALESCE(SUM(total), 0) as total_sales
        FROM orders
        WHERE DATE(created_at) = ? AND status = 'completed'
    ");
    $stmt->execute([$date]);
    $summary = $stmt->fetch();
    
    // Get orders for that date
    $stmt = $pdo->prepare("
        SELECT o.*, s.name as student_name, s.student_id
        FROM orders o
        JOIN students s ON o.student_id = s.id
        WHERE DATE(o.created_at) = ? AND o.status = 'completed'
        ORDER BY o.created_at DESC
    ");
    $stmt->execute([$date]);
    $orders = $stmt->fetchAll();
    
    sendResponse([
        'date' => $date,
        'total_orders' => $summary['total_orders'],
        'total_sales' => $summary['total_sales'],
        'orders' => $orders
    ]);
}

/**
 * Get transaction logs
 */
function getTransactions() {
    global $pdo;
    
    $stmt = $pdo->query("
        SELECT t.*, s.name as student_name
        FROM transactions t
        LEFT JOIN nfc_cards nc ON t.card_id = nc.id
        LEFT JOIN students s ON nc.student_id = s.id
        ORDER BY t.created_at DESC
        LIMIT 500
    ");
    
    $transactions = $stmt->fetchAll();
    
    sendResponse(['transactions' => $transactions]);
}

/**
 * Get reload logs
 */
function getReloads() {
    global $pdo;
    
    $stmt = $pdo->query("
        SELECT r.*, s.name as student_name, a.name as admin_name
        FROM reloads r
        LEFT JOIN nfc_cards nc ON r.card_id = nc.id
        LEFT JOIN students s ON nc.student_id = s.id
        LEFT JOIN admins a ON r.admin_id = a.id
        ORDER BY r.created_at DESC
        LIMIT 500
    ");
    
    $reloads = $stmt->fetchAll();
    
    sendResponse(['reloads' => $reloads]);
}

/**
 * Get dashboard statistics for reports
 */
function getDashboardStats() {
    global $pdo;
    
    // Daily sales (today)
    $stmt = $pdo->query("
        SELECT 
            COALESCE(SUM(total), 0) as daily_sales
        FROM orders
        WHERE DATE(created_at) = CURDATE() AND status = 'completed'
    ");
    $dailySalesResult = $stmt->fetch();
    $dailySales = $dailySalesResult['daily_sales'] ?? 0;
    
    // Completed orders today
    $stmt = $pdo->query("
        SELECT COUNT(*) as completed_orders
        FROM orders
        WHERE DATE(created_at) = CURDATE() AND status = 'completed'
    ");
    $completedResult = $stmt->fetch();
    $completedOrders = $completedResult['completed_orders'] ?? 0;
    
    // Total transactions
    $stmt = $pdo->query("
        SELECT COUNT(*) as total_transactions
        FROM transactions
    ");
    $transResult = $stmt->fetch();
    $totalTransactions = $transResult['total_transactions'] ?? 0;
    
    // Card reloads
    $stmt = $pdo->query("
        SELECT COUNT(*) as card_reloads
        FROM reloads
    ");
    $reloadsResult = $stmt->fetch();
    $cardReloads = $reloadsResult['card_reloads'] ?? 0;
    
    // Average order value
    $stmt = $pdo->query("
        SELECT 
            COALESCE(AVG(total), 0) as avg_order_value
        FROM orders
        WHERE status = 'completed'
    ");
    $avgResult = $stmt->fetch();
    $avgOrderValue = $avgResult['avg_order_value'] ?? 0;
    
    sendResponse([
        'stats' => [
            'daily_sales' => floatval($dailySales),
            'completed_orders' => intval($completedOrders),
            'total_transactions' => intval($totalTransactions),
            'card_reloads' => intval($cardReloads),
            'avg_order_value' => floatval($avgOrderValue)
        ]
    ]);
}

/**
 * Export data to CSV
 */
function exportCSV() {
    global $pdo;
    
    $type = $_GET['type'] ?? 'transactions';
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $type . '-' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    switch ($type) {
        case 'transactions':
            fputcsv($output, [
                'ID', 'Card ID', 'Student Name', 'Type', 'Amount', 'Reason',
                'Balance Before', 'Balance After', 'Date & Time'
            ]);
            
            $stmt = $pdo->query("
                SELECT t.*, s.name as student_name
                FROM transactions t
                LEFT JOIN nfc_cards nc ON t.card_id = nc.id
                LEFT JOIN students s ON nc.student_id = s.id
                ORDER BY t.created_at DESC
            ");
            
            while ($row = $stmt->fetch()) {
                fputcsv($output, [
                    $row['id'],
                    $row['card_id'],
                    $row['student_name'] ?? 'Unknown',
                    $row['type'],
                    number_format($row['amount'], 2),
                    $row['reason'] ?? '',
                    number_format($row['balance_before'], 2),
                    number_format($row['balance_after'], 2),
                    $row['created_at']
                ]);
            }
            break;
            
        case 'orders':
            fputcsv($output, [
                'Order ID', 'Student ID', 'Student Name', 'Total', 'Status',
                'Created At', 'Completed At'
            ]);
            
            $stmt = $pdo->query("
                SELECT o.*, s.name as student_name, s.student_id as student_number
                FROM orders o
                JOIN students s ON o.student_id = s.id
                ORDER BY o.created_at DESC
            ");
            
            while ($row = $stmt->fetch()) {
                fputcsv($output, [
                    $row['id'],
                    $row['student_number'],
                    $row['student_name'],
                    number_format($row['total'], 2),
                    $row['status'],
                    $row['created_at'],
                    $row['completed_at'] ?? ''
                ]);
            }
            break;
            
        case 'reloads':
            fputcsv($output, [
                'ID', 'Card ID', 'Student Name', 'Amount', 'Admin Name',
                'Balance Before', 'Balance After', 'Date & Time'
            ]);
            
            $stmt = $pdo->query("
                SELECT r.*, s.name as student_name, a.name as admin_name
                FROM reloads r
                LEFT JOIN nfc_cards nc ON r.card_id = nc.id
                LEFT JOIN students s ON nc.student_id = s.id
                LEFT JOIN admins a ON r.admin_id = a.id
                ORDER BY r.created_at DESC
            ");
            
            while ($row = $stmt->fetch()) {
                fputcsv($output, [
                    $row['id'],
                    $row['card_id'],
                    $row['student_name'] ?? 'Unknown',
                    number_format($row['amount'], 2),
                    $row['admin_name'] ?? 'Unknown',
                    number_format($row['balance_before'], 2),
                    number_format($row['balance_after'], 2),
                    $row['created_at']
                ]);
            }
            break;
            
        default:
            fputcsv($output, ['Error', 'Invalid export type']);
    }
    
    fclose($output);
    exit;
}
?>
