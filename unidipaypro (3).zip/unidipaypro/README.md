# UniDiPay - PHP/MySQL Version

**Complete XAMPP-ready implementation**

## 📁 File Structure

```
unidipay/
├── index.html                 # Login page
├── dashboard.html            # Dashboard
├── users.html                # User Management
├── nfc.html                  # NFC Management
├── menu.html                 # Menu Management
├── orders.html               # Order Monitoring
├── reports.html              # Reports
├── css/
│   └── style.css            # Main stylesheet
├── js/
│   ├── main.js              # Common functions
│   ├── dashboard.js         # Dashboard logic
│   ├── users.js             # User management
│   ├── nfc.js               # NFC operations
│   ├── menu.js              # Menu management
│   ├── orders.js            # Order monitoring
│   └── reports.js           # Reports
├── php/
│   ├── config/
│   │   └── database.php     # DB connection
│   ├── api/
│   │   ├── auth.php         # Authentication
│   │   ├── students.php     # Student CRUD
│   │   ├── nfc.php          # NFC operations
│   │   ├── menu.php         # Menu CRUD
│   │   ├── orders.php       # Order CRUD
│   │   └── reports.php      # Reports & analytics
│   └── includes/
│       └── functions.php    # Helper functions
└── sql/
    ├── schema.sql           # Database structure
    └── sample_data.sql      # Demo data
```

## 🚀 Installation Steps

### 1. Install XAMPP
- Download from https://www.apachefriends.org/
- Install with Apache and MySQL

### 2. Setup Database
1. Start XAMPP Control Panel
2. Start Apache and MySQL
3. Open phpMyAdmin (http://localhost/phpmyadmin)
4. Create new database: `unidipay_db`
5. Import `/sql/schema.sql`
6. Import `/sql/sample_data.sql` (optional)

### 3. Deploy Files
1. Copy entire `unidipay` folder to `C:\xampp\htdocs\`
2. Access at: http://localhost/unidipay/

### 4. Configure Database
Edit `php/config/database.php`:
```php
$host = 'localhost';
$dbname = 'unidipay_db';
$username = 'root';
$password = ''; // Your MySQL password
```

### 5. Login
- Default admin: admin@unidipay.com
- Password: admin123
- (Or create new admin via phpMyAdmin)

## 🔧 System Requirements

- XAMPP 8.0+ (PHP 8.0+, MySQL 5.7+)
- Modern web browser
- Windows/Mac/Linux

## 📝 Features

✅ Admin Authentication  
✅ Dashboard with Statistics  
✅ User Management (CRUD)  
✅ NFC Card Management  
✅ Menu Management  
✅ Order Monitoring  
✅ Reports & CSV Export  

## 🆘 Troubleshooting

**"Cannot connect to database"**
- Check MySQL is running in XAMPP
- Verify database credentials in config/database.php

**"404 Not Found"**
- Ensure files are in htdocs/unidipay/
- Check Apache is running

**"Session error"**
- Ensure session_start() works
- Check PHP error logs

## 📚 Documentation

See main README.md for complete feature documentation.

**Version**: 1.0.0 (PHP/MySQL)  
**Compatible**: XAMPP 8.0+
