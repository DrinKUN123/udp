-- ============================================
-- UniDiPay Database Schema
-- MySQL/MariaDB Version for XAMPP
-- ============================================

-- Drop existing tables if they exist
DROP TABLE IF EXISTS receipts;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS reloads;
DROP TABLE IF EXISTS menu_items;
DROP TABLE IF EXISTS nfc_cards;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS admins;

-- ============================================
-- ADMINS TABLE
-- ============================================
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- STUDENTS TABLE
-- ============================================
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    student_id VARCHAR(50) UNIQUE NOT NULL,
    program VARCHAR(100) NOT NULL,
    year_level VARCHAR(20) NOT NULL,
    nfc_card_id VARCHAR(50) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- NFC CARDS TABLE
-- ============================================
CREATE TABLE nfc_cards (
    id VARCHAR(50) PRIMARY KEY,
    student_id INT NOT NULL,
    balance DECIMAL(10, 2) DEFAULT 0.00 CHECK (balance >= 0),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- MENU ITEMS TABLE
-- ============================================
CREATE TABLE menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category ENUM('Meals', 'Drinks', 'Snacks', 'Desserts') NOT NULL,
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    description TEXT,
    image_url TEXT,
    available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- ORDERS TABLE
-- ============================================
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    nfc_card_id VARCHAR(50) NOT NULL,
    total DECIMAL(10, 2) NOT NULL CHECK (total >= 0),
    status ENUM('pending', 'processing', 'ready', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (nfc_card_id) REFERENCES nfc_cards(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- ORDER ITEMS TABLE
-- ============================================
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    menu_item_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TRANSACTIONS TABLE
-- ============================================
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    card_id VARCHAR(50) NOT NULL,
    type ENUM('debit', 'credit') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL CHECK (amount > 0),
    reason TEXT,
    order_id INT NULL,
    balance_before DECIMAL(10, 2) NOT NULL,
    balance_after DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (card_id) REFERENCES nfc_cards(id),
    FOREIGN KEY (order_id) REFERENCES orders(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- RELOADS TABLE
-- ============================================
CREATE TABLE reloads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    card_id VARCHAR(50) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL CHECK (amount > 0),
    admin_id INT NOT NULL,
    balance_before DECIMAL(10, 2) NOT NULL,
    balance_after DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (card_id) REFERENCES nfc_cards(id),
    FOREIGN KEY (admin_id) REFERENCES admins(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- RECEIPTS TABLE
-- ============================================
CREATE TABLE receipts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT UNIQUE NOT NULL,
    items JSON NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX idx_students_student_id ON students(student_id);
CREATE INDEX idx_students_nfc_card ON students(nfc_card_id);
CREATE INDEX idx_nfc_cards_student ON nfc_cards(student_id);
CREATE INDEX idx_nfc_cards_balance ON nfc_cards(balance);
CREATE INDEX idx_menu_items_category ON menu_items(category);
CREATE INDEX idx_menu_items_available ON menu_items(available);
CREATE INDEX idx_orders_student ON orders(student_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created ON orders(created_at DESC);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_transactions_card ON transactions(card_id);
CREATE INDEX idx_transactions_type ON transactions(type);
CREATE INDEX idx_transactions_created ON transactions(created_at DESC);
CREATE INDEX idx_reloads_card ON reloads(card_id);
CREATE INDEX idx_reloads_admin ON reloads(admin_id);
CREATE INDEX idx_reloads_created ON reloads(created_at DESC);
CREATE INDEX idx_receipts_order ON receipts(order_id);

-- ============================================
-- INSERT DEFAULT ADMIN
-- ============================================
-- Password: admin123 (hashed with PASSWORD_DEFAULT)
INSERT INTO admins (email, password, name) VALUES 
('admin@unidipay.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator');

-- ============================================
-- VIEWS FOR REPORTING
-- ============================================

-- Daily Sales Summary
CREATE OR REPLACE VIEW daily_sales_summary AS
SELECT 
    DATE(created_at) as sale_date,
    COUNT(*) as total_orders,
    SUM(total) as total_sales,
    AVG(total) as average_order_value
FROM orders
WHERE status = 'completed'
GROUP BY DATE(created_at)
ORDER BY sale_date DESC;

-- Low Balance Cards
CREATE OR REPLACE VIEW low_balance_cards AS
SELECT 
    nc.id as card_id,
    nc.balance,
    s.name as student_name,
    s.student_id,
    s.program
FROM nfc_cards nc
JOIN students s ON nc.student_id = s.id
WHERE nc.balance < 100
ORDER BY nc.balance ASC;

-- Popular Menu Items
CREATE OR REPLACE VIEW popular_menu_items AS
SELECT 
    mi.id,
    mi.name,
    mi.category,
    mi.price,
    COUNT(oi.id) as times_ordered,
    SUM(oi.quantity) as total_quantity,
    SUM(oi.subtotal) as total_revenue
FROM menu_items mi
LEFT JOIN order_items oi ON mi.id = oi.menu_item_id
GROUP BY mi.id, mi.name, mi.category, mi.price
ORDER BY total_quantity DESC;

-- ============================================
-- STORED PROCEDURES
-- ============================================

DELIMITER //

-- Procedure to create order with payment
CREATE PROCEDURE create_order_with_payment(
    IN p_student_id INT,
    IN p_nfc_card_id VARCHAR(50),
    IN p_items JSON,
    IN p_total DECIMAL(10, 2),
    OUT p_order_id INT,
    OUT p_error VARCHAR(255)
)
BEGIN
    DECLARE v_current_balance DECIMAL(10, 2);
    DECLARE v_new_balance DECIMAL(10, 2);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_error = 'Transaction failed';
        SET p_order_id = NULL;
    END;

    START TRANSACTION;

    -- Check card balance
    SELECT balance INTO v_current_balance
    FROM nfc_cards
    WHERE id = p_nfc_card_id
    FOR UPDATE;

    IF v_current_balance < p_total THEN
        SET p_error = 'Insufficient balance';
        SET p_order_id = NULL;
        ROLLBACK;
    ELSE
        -- Create order
        INSERT INTO orders (student_id, nfc_card_id, total, status)
        VALUES (p_student_id, p_nfc_card_id, p_total, 'pending');
        
        SET p_order_id = LAST_INSERT_ID();

        -- Deduct balance
        SET v_new_balance = v_current_balance - p_total;
        UPDATE nfc_cards SET balance = v_new_balance WHERE id = p_nfc_card_id;

        -- Record transaction
        INSERT INTO transactions (card_id, type, amount, reason, order_id, balance_before, balance_after)
        VALUES (p_nfc_card_id, 'debit', p_total, CONCAT('Order #', p_order_id), p_order_id, v_current_balance, v_new_balance);

        SET p_error = NULL;
        COMMIT;
    END IF;
END //

DELIMITER ;

-- ============================================
-- TRIGGERS
-- ============================================

-- Auto-generate receipt when order is completed
DELIMITER //

CREATE TRIGGER generate_receipt_on_complete
AFTER UPDATE ON orders
FOR EACH ROW
BEGIN
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        INSERT INTO receipts (order_id, items, total)
        SELECT 
            NEW.id,
            JSON_ARRAYAGG(
                JSON_OBJECT(
                    'name', oi.name,
                    'price', oi.price,
                    'quantity', oi.quantity,
                    'subtotal', oi.subtotal
                )
            ),
            NEW.total
        FROM order_items oi
        WHERE oi.order_id = NEW.id;
        
        -- Set completed timestamp
        UPDATE orders SET completed_at = NOW() WHERE id = NEW.id;
    END IF;
END //

DELIMITER ;

-- ============================================
-- END OF SCHEMA
-- ============================================
